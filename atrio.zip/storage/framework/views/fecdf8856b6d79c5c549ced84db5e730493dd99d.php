<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<!------------------------------------------------------------------------------------------>

<!--@section('button-visibility','hidden')-->
<?php $__env->startSection('button-return-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-return-href','/services'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('logo-avatar', './../img/logo-menu/parking.png'); ?>
<?php $__env->startSection('title-grid', 'Saída / Entrada'); ?>
<?php $__env->startSection('title-color','purple'); ?>
<?php $__env->startSection('subtitle-grid', 'selecione a opção desejada'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option1-href','car/out'); ?>
<?php $__env->startSection('button-option1-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-option1-name','Retirar'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option2-href','car/in'); ?>
<?php $__env->startSection('button-option2-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-option2-name','Devolver'); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>