<?php $__env->startSection('title', 'PortControl | 1.0'); ?>

<?php $__env->startSection('button-return'); ?>

    <form action="<?php echo e(route('services.car.out.places')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

        <div>
            <button  type="submit" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light pulse"><i class="material-icons">arrow_back</i></button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo-avatar', './../../../img/logo-menu/summary.png'); ?>

<?php $__env->startSection('title-grid', 'Você confirma?'); ?>

<?php $__env->startSection('subtitle-grid', 'Resumo das informações selecionadas'); ?>

<?php $__env->startSection('options'); ?>

    <div class="row col s12">
        <div class="card-panel lime accent-1">
            <div class="center">
                <p><b><font size="5" face="Courier">LEGIÃO DA BOA VONTADE</font></b></p>
            </div>
            <div class="center">
                <p><font size="3" face="Courier">COMPROVANTE DE REGISTRO DE RETIRADA <br> DE VEÍCULOS</font></p>
            </div>
            <div class="center">
                <p class="margin">
                    <font size="3" face="Courier">
                        EMISSOR: <?php echo e(str_pad(Session::get('user'),30,".",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        STATUS: <?php echo e(str_pad(Session::get('status'),31,".",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        SERVIÇO: <?php echo e(str_pad(Session::get('service'),30,".",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        MOTORISTA: <?php echo e(str_pad(Session::get('driver'),28,".",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        VEÍCULO: <?php echo e(str_pad(Session::get('car'),30,".",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        LOCALIDADE: <?php echo e(str_pad(Session::get('place'),27,".",STR_PAD_LEFT)); ?>

                    </font>
                </p>
            </div>
            <br>
            <div class="center">
                <p class="margin">
                    <font size="3" face="Courier">
                        <?php echo e(str_pad('',39,"-",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        APRESENTAR COMPROVANTE NA GARAGEM
                    </font>
                </p>
                <p class="margin">
                    <font size="3" face="Courier">
                        <?php echo e(str_pad('',39,"-",STR_PAD_LEFT)); ?>

                    </font>
                </p>
            </div>
            <br>
            <br>
            <div>
                <p class="margin center">
                    <font size="3" face="Courier">
                        <?php echo e(str_pad('',39,"-",STR_PAD_LEFT)); ?>

                    </font>
                </p>
                <p class="margin center">
                    <font size="2" face="Courier">
                        ASSINATURA DO RESPONSÁVEL
                    </font>
                </p>
            </div>
        </div>
    </div>

    <div class="row center col s12">
        <form action="<?php echo e(route('services.car.out.summary')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

            <div>
                <button  type="submit" class="gradient-45deg-deep-orange-orange amber waves-effect waves-light btn border-round box-shadow pulse">Confirmar</button>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.templates.page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>