<!------------------------------------------------------------------------------------------>

<!--@section('button-visibility','hidden')-->
<!--@section('button-return-color','')-->
<?php $__env->startSection('button-return-href','home'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('logo-avatar', './img/logo-menu/question-login.png'); ?>
<?php $__env->startSection('title-grid', 'Quem é você?'); ?>
<?php $__env->startSection('subtitle-grid', 'Selecione uma opção de identificação'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option1-href',''); ?>
<!--@section('button-option1-color','gradient-45deg-purple-deep-orange')-->
<?php $__env->startSection('button-option1-name','Biometria'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option2-href','login'); ?>
<!--@section('button-option2-color','gradient-45deg-purple-deep-orange')-->
<?php $__env->startSection('button-option2-name','CPF / Nascimento'); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            $('.tap-target').tapTarget('open');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '2'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>