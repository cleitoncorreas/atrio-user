<!------------------------------------------------------------------------------------------>

<!--@section('button-visibility','hidden')-->
<!--@section('button-return-color','')-->
<?php $__env->startSection('button-return-href','login/out'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('logo-avatar', './img/logo-menu/concierge.png'); ?>
<?php $__env->startSection('title-grid', 'Como posso ajudar?'); ?>
<?php $__env->startSection('subtitle-grid', 'selecione o serviço desejado'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option1-href','services/key'); ?>
<?php $__env->startSection('button-option1-color','gradient-45deg-green-teal'); ?>
<?php $__env->startSection('button-option1-name','Chaves'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option2-href','services/correspondence'); ?>
<!--@section('button-option2-color','gradient-45deg-purple-deep-orange')-->
<?php $__env->startSection('button-option2-name','Correspondência'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option3-href','services/car'); ?>
<?php $__env->startSection('button-option3-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-option3-name','Veículos'); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '3'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>