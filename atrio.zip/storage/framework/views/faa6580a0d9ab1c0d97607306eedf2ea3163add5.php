<?php $__env->startSection('title', 'PortControl | 1.0'); ?>

<?php $__env->startSection('button-return'); ?>

    <div>
        <a href="<?php echo e(route('identification')); ?>" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light pulse"><i class="material-icons">arrow_back</i></a>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo-avatar', './img/shield.png'); ?>

<?php $__env->startSection('title-grid', 'Identifique-se!'); ?>

<?php $__env->startSection('subtitle-grid', 'digite seus dados'); ?>

<?php $__env->startSection('options'); ?>

<style>
/* label color */
.input-field label {
     color: #000;
   }
   /* label focus color */
   .input-field input[type=text]:focus + label {
     color: #2196f3 !important;
   }
   /* label underline focus color */
   .input-field input[type=text]:focus {
     border-bottom: 1px solid #2196f3 !important;
     box-shadow: 0 1px 0 0 #2196f3 !important;
   }

   /* label focus color */
   .input-field input[type=password]:focus + label {
     color: #2196f3 !important;
   }
   /* label underline focus color */
   .input-field input[type=password]:focus {
     border-bottom: 1px solid #2196f3 !important;
     box-shadow: 0 1px 0 0 #2196f3 !important;
   }

   /* valid color */
   .input-field input[type=text].valid {
     border-bottom: 1px solid #2196f3;
     box-shadow: 0 1px 0 0 #2196f3;
   }
   /* invalid color */
   .input-field input[type=text].invalid {
     border-bottom: 1px solid #2196f3;
     box-shadow: 0 1px 0 0 #2196f3;
   }
   /* icon prefix focus color */
   .input-field .prefix.active {
     color: #2196f3;
   }
</style>
       
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<form name="form" action="<?php echo e(route('autenticationIn')); ?>" method="post">
<?php echo csrf_field(); ?>
    <div class="col s9 offset-s2">
        <div class="row margin">
            <div class="input-field col s11">
                <i class="ion ion-ios-contact-outline prefix pt-5"></i>
                <!--<i class="material-icons prefix pt-5">person_outline</i>-->
                <input placeholder="CPF" name="username" id="username" type="text">
                <label id="user" for="username">Usuário (CPF)</label>
            </div>
        </div>
        <div class="row margin">
            <div class="input-field col s11">
                <i class="ion ion-android-lock prefix pt-5"></i>
                <!--<i class="material-icons prefix pt-5">lock_outline</i>-->
                <input placeholder="Nascimento" name="password" id="password" type="password">
                <label id="pass" for="password">Senha (Nascimento)</label>
            </div>
        </div>
        <table class="" id="keybord">
            <tr> 
                <td><button type="button" name="num1" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="1" onclick="calcNum(1)"/>1</button></td>
                <td><button type="button" name="num2" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="2" onclick="calcNum(2)"/>2</button></td>
                <td><button type="button" name="num3" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="3" onclick="calcNum(3)"/>3</button></td>
            </tr>  
            <tr>
                <td><button type="button" name="num4" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="4" onclick="calcNum(4)"/>4</button></td>
                <td><button type="button" name="num5" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="5" onclick="calcNum(5)"/>5</button></td>
                <td><button type="button" name="num6" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="6" onclick="calcNum(6)"/>6</button></td>
            </tr>  
            <tr>
                <td><button type="button" name="num7" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="7" onclick="calcNum(7)"/>7</button></td>
                <td><button type="button" name="num8" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="8" onclick="calcNum(8)"/>8</button></td>
                <td><button type="button" name="num9" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="9" onclick="calcNum(9)"/>9</button></td>
            </tr>  
            <tr>
                <td><button type="button" name="limpar" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text" onclick="calcLimpar()"/><i class="material-icons">backspace</i></button></td>
                <td><button type="button" name="num0" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light flow-text num" value="0" onclick="calcNum(0)"/>0</button></td>
                <td><button type="submit" class="btn-floating gradient-45deg-deep-orange-orange amber btn-large waves-effect waves-light flow-text"><i class="material-icons">keyboard_return</i></button></td>
            </tr>        
        </table>
    </div>

    <div class="row">
        <div class="input-field col s6 m6 l6">
            <p class="margin medium-small grey-text"></p>
        </div>
        <!--<div class="input-field col s6 m6 l6">
            <p class="margin right-align medium-small"><a href="#">Esqueceu a senha?</a></p>
        </div>-->
    </div>
</form>

<?php $__env->stopSection(); ?>


<script>

// Função que adiciona os números no Visor quando pressionado os botões
function calcNum(num) {
    
    if (document.form.username.value.length < 11) {
         document.form.username.value = document.form.username.value + num;
    } else {
 
         if (document.form.password.value.length < 8) {
         document.form.password.value = document.form.password.value + num;
         } else {
 
         }
    }
 
 }
 
 // Função que limpa a calculadora e todas as variáveis existentes.
 function calcLimpar() {
    document.form.username.value  = '';
    document.form.password.value = '';
 }


</script>

<?php echo $__env->make('vendor.templates.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>