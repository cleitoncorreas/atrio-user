<?php $__env->startSection('title', 'PortControl | 1.0'); ?>

<?php $__env->startSection('button-return'); ?>

    <div>
        <a href="<?php echo e(route('home')); ?>" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light pulse"><i class="material-icons">arrow_back</i></a>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('logo-avatar', './img/identification.png'); ?>

<?php $__env->startSection('title-grid', 'Quem é você?'); ?>

<?php $__env->startSection('subtitle-grid', 'Selecione uma opção de identificação'); ?>

<?php $__env->startSection('options'); ?>


    <div class="row center col s12">
        <a href="" id="download-button" class="gradient-45deg-indigo-light-blue blue disabled btn-large z-depth-5 waves-effect waves-light border-round col s12">Identificação por Biometria</a>
    </div>
    <div class="row center col s12">
        <a href="<?php echo e(route('autentication')); ?>" id="download-button" class="gradient-45deg-indigo-light-blue blue btn-large z-depth-5 waves-effect waves-light border-round pulse col s12">Identificação por CPF</a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.templates.page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>