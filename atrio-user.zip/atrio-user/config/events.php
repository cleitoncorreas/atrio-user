<?php

return [

    'drivers' => [
        'cpf'      => '323232',
        'service'  => '1',
        'type'     => '1',
        'id_driver'=> '1',
        'id_car'   => '1',
        'place'    => '1',
        'id_user'  => '1'
    ]
];