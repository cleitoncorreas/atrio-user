<?php $__env->startSection('title', 'PortControl | 1.0'); ?>

<?php $__env->startSection('button-return'); ?>

    <div>
        <a href="<?php echo e(route('login')); ?>" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light pulse"><i class="material-icons">arrow_back</i></a>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo-avatar', './img/concierge.png'); ?>

<?php $__env->startSection('title-grid', 'Como posso ajudar?'); ?>

<?php $__env->startSection('subtitle-grid', 'Selecione o serviço desejado'); ?>

<?php $__env->startSection('options'); ?>

    <div class="row center col s12">
        <a href="" id="download-button" class="gradient-45deg-indigo-light-blue blue btn-large z-depth-5 waves-effect waves-light border-round pulse col s12">Chaves</a>
    </div>
    <div class="row center col s12">
        <a href="" id="download-button" class="gradient-45deg-indigo-light-blue blue btn-large z-depth-5 waves-effect waves-light border-round pulse col s12">Correspondência</a>
    </div>
    <div class="row center col s12">
        <a href="" id="download-button" class="gradient-45deg-indigo-light-blue blue btn-large z-depth-5 waves-effect waves-light border-round pulse col s12">Veículos</a>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.templates.page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>