<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<!--@section('button-visibility','hidden')-->
<?php $__env->startSection('button-return-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-return-href','/services/car/out/list/places'); ?>

<?php $__env->startSection('logo-avatar', './../../../../img/logo-menu/summary2.png'); ?>
<?php $__env->startSection('title-grid', 'Você confirma?'); ?>
<?php $__env->startSection('title-color','purple'); ?>
<?php $__env->startSection('subtitle-grid', 'resumo das informações selecionadas'); ?>

<?php $__env->startSection('button-summary-login-href','/login/out'); ?>
<?php $__env->startSection('button-summary-login-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-summary-service-href',''/*'/services'*/); ?>
<?php $__env->startSection('button-summary-service-color','gradient-45deg-blue-grey-blue-grey'); ?>
<?php $__env->startSection('button-summary-status-href',''/*'/services/car'*/); ?>
<?php $__env->startSection('button-summary-status-color','gradient-45deg-blue-grey-blue-grey'); ?>
<?php $__env->startSection('button-summary-driver-href','/services/car/out/list/drivers'); ?>
<?php $__env->startSection('button-summary-driver-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-summary-car-href','/services/car/out/list/cars'); ?>
<?php $__env->startSection('button-summary-car-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-summary-place-href','/services/car/out/list/places'); ?>
<?php $__env->startSection('button-summary-place-color','gradient-45deg-purple-deep-orange'); ?>

<?php $__env->startSection('button-summary-confirm-action','/services/car/out/summary/confirm'); ?>
<?php $__env->startSection('button-summary-confirm-color','gradient-45deg-purple-deep-orange'); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '6'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>