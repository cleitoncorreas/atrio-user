<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<!--@section('button-visibility','hidden')-->
<?php $__env->startSection('button-return-color','gradient-45deg-purple-deep-orange'); ?>

<?php if(Session::get('count_driver')>0): ?>
    <?php $__env->startSection('button-return-href','/services/car/out'); ?>
<?php else: ?> 
    <?php $__env->startSection('button-return-href','/services/car'); ?>
<?php endif; ?>

<?php $__env->startSection('logo-avatar', './../../../../img/logo-menu/drivers.png'); ?>
<?php $__env->startSection('title-grid', 'Motoristas'); ?>
<?php $__env->startSection('title-color','purple'); ?>
<?php $__env->startSection('subtitle-grid', 'Selecione o motorista abaixo'); ?>

<!--@section('carousel-image','')-->
<?php $__env->startSection('card-content-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-prev-next-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('form-action','driver/select'); ?>
<?php $__env->startSection('form-input-name','id_motorista'); ?>
<?php $__env->startSection('button-select-color','gradient-45deg-purple-deep-orange'); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '5'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>