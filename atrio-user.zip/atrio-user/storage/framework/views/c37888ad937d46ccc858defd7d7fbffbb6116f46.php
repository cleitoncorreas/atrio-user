<?php $__env->startSection('title', 'PortControl | 1.0'); ?>

<?php $__env->startSection('button-return'); ?>

    <div>
        <a href="<?php echo e(route('services')); ?>" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light pulse"><i class="material-icons">arrow_back</i></a>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo-avatar', './img/taxi-driver.png'); ?>

<?php 
$se = '0';
$msg = ($se == 0 ? 'Você será o motorista?' : 'Você foi o motorista?')?>
<?php $__env->startSection('title-grid', $msg); ?>

<?php $__env->startSection('subtitle-grid', 'Selecione a opção solicitada'); ?>

<?php $__env->startSection('options'); ?>

    <div class="row center col s12">
        <a href="" id="download-button" class="gradient-45deg-indigo-light-blue blue btn-large z-depth-5 waves-effect waves-light border-round pulse col s12">sim</a>
    </div>
    <div class="row center col s12">
        <a href="" id="download-button" class="gradient-45deg-indigo-light-blue blue btn-large z-depth-5 waves-effect waves-light border-round pulse col s12">não</a>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.templates.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>