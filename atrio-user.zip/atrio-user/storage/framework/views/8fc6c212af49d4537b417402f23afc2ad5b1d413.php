<?php $__env->startSection('body'); ?>

    <div id="login-pag" class="row">
        <div class="animated fadeInDown col s12 z-depth-5 card-panel border-round" id="seletor">
            <div class="row">
                <div class="input-field col s12 mt-5">
                    <div class="animated zoomIn ">
                        <a style="visibility:<?php echo $__env->yieldContent('button-return-visibility'); ?>" href="<?php echo $__env->yieldContent('button-return-href'); ?>" class="btn-floating <?php echo $__env->yieldContent('button-return-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large waves-effect waves-light"><i class="material-icons">arrow_back</i></a>
                    </div>
                    
                    <div class="animated pulse infinite center">
                        <img src="<?php echo $__env->yieldContent('logo-avatar','./img/logo-menu/default.png'); ?>" alt="" class="responsive-img valign" id="ico-menu" id="seletor">
                    </div>
                  <!--<p class="center login-form-text"><?php echo $__env->yieldContent('title-grid'); ?></p>-->
                </div>
                <div class="animated bounce input-field col s12 center mb-5">
                    <h3 class="header center <?php echo $__env->yieldContent('title-color','blue'); ?>-text text-darken-4 light" id="seletor"><?php echo $__env->yieldContent('title-grid'); ?><span style="font-size:15px"><?php echo $__env->yieldContent('title-subgrid'); ?></span></h3>
                    <h5 class="font-weight-100 center black-text text-darken-4 light" id="seletor"><?php echo $__env->yieldContent('subtitle-grid'); ?></h5>
                </div>
            </div>


            <?php switch($option):
                case ('1'): ?>
                    <div class="animated zoomIn row center col s12 mb-5">
                        <a href="<?php echo $__env->yieldContent('button-option1-href'); ?>" class="<?php echo $__env->yieldContent('button-option1-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12"><?php echo $__env->yieldContent('button-option1-name'); ?><!--<i class="material-icons ml-6 left">cloud_download</i>--></a>
                    </div>
                <?php break; ?>

                <?php case ('2'): ?>
                    <div class="animated zoomIn row center col s12 mb-3">
                        <a href="<?php echo $__env->yieldContent('button-option1-href'); ?>" class="<?php echo $__env->yieldContent('button-option1-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12"><?php echo $__env->yieldContent('button-option1-name'); ?></a>
                    </div>
                    <div class="animated zoomIn row center col s12 mb-6">
                        <a href="<?php echo $__env->yieldContent('button-option2-href'); ?>" class="<?php echo $__env->yieldContent('button-option2-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12"><?php echo $__env->yieldContent('button-option2-name'); ?></a>
                    </div>
                <?php break; ?>

                <?php case ('3'): ?>
                    <div class="animated zoomIn row center col s12 mb-3">
                        <i class="material-icons teal-text" style="position: absolute; top: -7px; right:2%; z-index:2">lens</i>
                        <a href="<?php echo $__env->yieldContent('button-option1-href'); ?>" class="<?php echo $__env->yieldContent('button-option1-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12"><?php echo $__env->yieldContent('button-option1-name'); ?><!--</span><span class="badge badge pill float-right mt-2 red">30</span>--></a>
                    </div>
                    <div class="animated zoomIn row center col s12 mb-3">
                        <i class="material-icons blue-text" style="position: absolute; top: -7px; right:2%; z-index:2">lens</i>
                        <a href="<?php echo $__env->yieldContent('button-option2-href'); ?>" class="<?php echo $__env->yieldContent('button-option2-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12"><?php echo $__env->yieldContent('button-option2-name'); ?></a>
                    </div>
                    <div class="animated zoomIn row center col s12 mb-5">
                        <i class="material-icons orange-text" style="position: absolute; top: -7px; right:2%; z-index:2">lens</i>
                        <a href="<?php echo $__env->yieldContent('button-option3-href'); ?>" class="<?php echo $__env->yieldContent('button-option3-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12"><?php echo $__env->yieldContent('button-option3-name'); ?></a>
                    </div>
                <?php break; ?>

                <?php case ('4'): ?>
                    <?php echo $__env->yieldContent('login'); ?>
                <?php break; ?>

                <?php case ('5'): ?>
                    <div class="center col s12">
                        <div class="row carousel carousel-slider border-round" data-indicators="true">
                            <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($dir):
                                    case ('img\cars'): ?>
                                        <div class="col s12 carousel-item"  data-cindex="<?php echo e($line->id); ?>" id="seletor">
                                            <?php if(file_exists(public_path($dir.'\\'.$line->foto))): ?>
                                                <div class="card blue-grey darken-4 z-depth-5 responsive-img border-round" style="background-image:url('./../../../../<?php echo e(str_replace('\\','/',$dir)); ?>/<?php echo e($line->foto); ?>');width: 100%;height: 100%;background-size:cover;background-position:cover;">
                                            <?php else: ?> 
                                                <div class="card blue-grey darken-4 z-depth-5 responsive-img border-round" style="background-image:url('./../../../../img/img-default.jpg');width: 100%;height: 100%;background-size: cover;background-position:center">
                                            <?php endif; ?>
                                                    <div class="animated pulse infinite input-field <?php echo $__env->yieldContent('card-content-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow card-content card-panel col s6 z-depth-5" style="opacity:.8">
                                                        <span class="card-title font-weight-600 mb-10 white-text"><?php echo e($line->modelo); ?></span>
                                                        <p class="white-text"><?php echo e($line->marca); ?>

                                                        <br> <?php echo e($line->placa); ?></p>
                                                    </div>
                                                </div>
                                        </div>
                                    <?php break; ?>
                                    <?php case ('img\drivers'): ?>
                                        <div class="col s12 carousel-item"  data-cindex="<?php echo e($line->funcionario->id); ?>" id="seletor">
                                            <?php if(file_exists(public_path($dir.'\\'.$line->foto))): ?>
                                                <div class="card blue-grey darken-4 z-depth-5 responsive-img border-round" style="background-image:url('./../../../../<?php echo e(str_replace('\\','/',$dir)); ?>/<?php echo e($line->foto); ?>');width: 100%;height: 100%;background-size:cover;background-position:center;">
                                            <?php else: ?> 
                                                <div class="card blue-grey darken-4 z-depth-5 responsive-img border-round" style="background-image:url('./../../../../img/img-default.jpg');width: 100%;height: 100%;background-size:cover;background-position:center">
                                            <?php endif; ?>
                                                    <div class="center">
                                                        <div class="animated pulse infinite input-field <?php echo $__env->yieldContent('card-content-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow card-content card-panel col s7 z-depth-5" style="opacity:.8">
                                                            <!--<img src="./../../../../<?php echo e(str_replace('\\','/',$dir)); ?>/<?php echo e($line->foto); ?>" class="responsive-img valign profile-image-login border-round">-->
                                                            <span class="font-weight-600 mb-10 white-text"><?php echo e($line->funcionario->nome); ?></span>
                                                            <!--<p class="white-text"><?php echo e($line->cnh); ?>

                                                            <br> <?php echo e($line->validade); ?></p>-->
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                        </div>
                                    <?php break; ?>
                                    <?php case ('img\places'): ?>
                                        <div class="col s12 carousel-item"  data-cindex="<?php echo e($line->id); ?>" id="seletor">
                                            <?php if(file_exists(public_path($dir.'\\'.$line->foto))): ?>
                                        <div class="card blue-grey darken-4 z-depth-5 responsive-img border-round" style="background-image:url('./../../../../<?php echo e(str_replace('\\','/',$dir)); ?>/<?php echo e($line->foto); ?>');width: 100%;height: 100%;background-size:cover;background-position:center;">
                                            <?php else: ?> 
                                                <div class="card blue-grey darken-4 z-depth-5 responsive-img border-round" style="background-image:url('./../../../../img/img-default.jpg');width: 100%;height: 100%;background-size:cover;background-position:center">
                                            <?php endif; ?>
                                                    <div class="animated pulse infinite input-field <?php echo $__env->yieldContent('card-content-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow card-content card-panel col s6 z-depth-5" style="opacity:.8">
                                                        <span class="font-weight-600 mb-10 white-text"><?php echo e($line->descricao); ?></span>
                                                        <p class="white-text"><?php echo e($line->endereco); ?>

                                                        <br> <?php echo e($line->telefone); ?></p>
                                                    </div>
                                                </div>
                                        </div>
                                    <?php break; ?>
                                <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <a class="btn-floating  <?php echo $__env->yieldContent('button-prev-next-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow waves-effect waves-light left prev" style="bottom:100px; margin: 20px"><i class="material-icons">arrow_back</i></a>
                        <a class="btn-floating  <?php echo $__env->yieldContent('button-prev-next-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow waves-effect waves-light right next" style="bottom:100px; margin: 20px"><i class="material-icons">arrow_forward</i></a>
                        
                        <form action="<?php echo $__env->yieldContent('form-action'); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class="mt-5">
                                <input type="hidden" name="<?php echo $__env->yieldContent('form-input-name'); ?>" class="id">
                                <button  type="submit" class="animated zoomIn <?php echo $__env->yieldContent('button-select-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow waves-effect waves-light btn border-round">Selecionar</button>
                            </div>
                        </form>
                    </div>

                    <?php $__env->startSection('js'); ?>
                        <script>

                            $(document).ready(function(){
                            
                            // function change
                                function changeIndex(index){
                                    $('.id').val(index);
                                }
                            
                            //active carousel
                                $('.carousel.carousel-slider').carousel({
                                    onCycleTo: function(index){
                                        changeIndex($(index).data('cindex'));
                                    }
                                });
                            
                            // function for next slide
                                $('.next').click(function(){
                                    $('.carousel').carousel('next');
                                });
                            
                            // function for prev slide
                                $('.prev').click(function(){
                                    $('.carousel').carousel('prev');
                                });
                            
                            });
                        
                        </script>
                    <?php $__env->stopSection(); ?>

                <?php break; ?>

                <?php case ('6'): ?>
                    <div class="row center col s12">
                        <div class="row mb-3">
                            <a href="<?php echo $__env->yieldContent('button-summary-login-href'); ?>" class="animated zoomInDown <?php echo $__env->yieldContent('button-summary-login-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12">
                                <img src="./../../../../img/logo-menu/shield.png" width="40" height="40" style="top:11%"  class="left"><?php echo e(Session::get('user')); ?>

                            </a>
                        </div>
                        <div class="row mb-3">
                            <a href="<?php echo $__env->yieldContent('button-summary-service-href'); ?>" class="animated zoomInDown <?php echo $__env->yieldContent('button-summary-service-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12">
                                <img src="./../../../../img/logo-menu/concierge.png" width="40" height="40" style="top:11%"  class="left"><?php echo e(Session::get('service')); ?>

                            </a>
                        </div>
                        <div class="row mb-3">
                            <a href="<?php echo $__env->yieldContent('button-summary-status-href'); ?>" class="animated zoomInDown <?php echo $__env->yieldContent('button-summary-status-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12">
                                <img src="./../../../../img/logo-menu/parking.png" width="40" height="40" style="top:11%"  class="left"><?php echo e(Session::get('status')); ?>

                            </a>
                        </div>
                        <div class="row mb-3">
                            <a href="<?php echo $__env->yieldContent('button-summary-driver-href'); ?>" class="animated zoomInDown <?php echo $__env->yieldContent('button-summary-driver-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12">
                                <img src="./../../../../img/logo-menu/driver.png" width="40" height="40" style="top:11%"  class="left"><?php echo e(Session::get('driver')); ?>

                            </a>
                        </div>
                        <div class="row mb-3">
                            <a href="<?php echo $__env->yieldContent('button-summary-car-href'); ?>" class="animated zoomInDown <?php echo $__env->yieldContent('button-summary-car-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12">
                                <img src="./../../../../img/logo-menu/cars.png" width="40" height="40" style="top:11%"  class="left"><?php echo e(Session::get('car')); ?>

                            </a>
                        </div>
                        <div class="row mb-3">
                            <a href="<?php echo $__env->yieldContent('button-summary-place-href'); ?>" class="animated zoomInDown <?php echo $__env->yieldContent('button-summary-place-color','gradient-45deg-indigo-light-blue'); ?> gradient-shadow btn-large z-depth-5 waves-effect waves-light border-round col s12">
                                <img src="./../../../../img/logo-menu/places.png" width="40" height="40" style="top:11%"  class="left"><?php echo e(Session::get('place')); ?>

                            </a>
                            <?php $page ?>
                        </div>
                    </div>
                 
                
                    <div class="row center col s12 mb-5">
                        <form action="<?php echo $__env->yieldContent('button-summary-confirm-action'); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div>
                                <button  type="submit" class="<?php echo $__env->yieldContent('button-summary-confirm-color','gradient-45deg-indigo-light-blue'); ?> waves-effect waves-light btn border-round box-shadow">Confirmar</button>
                            </div>
                        </form>
                    </div>
                <?php break; ?>

                <?php case ('7'): ?>
                    <div class="row offset-s2 mb-3" style="padding-left:30px; padding-right:30px">
                        <div id="div-print" class="card-panel col s12 lime accent-1 z-depth-3 black-text">
                            <div class="center">
                                <p style="text-align: center"><b><font size="4" face="Courier">LEGIÃO DA BOA VONTADE</font></b></p>
                            </div>
                            <div class="center">
                                <p style="text-align: center"><font size="2" face="Courier">COMPROVANTE DE REGISTRO DE RETIRADA DE VEÍCULOS</font></p>
                            </div>
                            <div style="text-align: center" class="center">
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        EMISSOR: <?php echo e(mb_strtoupper(str_pad(Session::get('user'),47,".",STR_PAD_LEFT))); ?>

                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        STATUS: <?php echo e(mb_strtoupper(str_pad(Session::get('status'),49,".",STR_PAD_LEFT))); ?>

                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        SERVIÇO: <?php echo e(mb_strtoupper(str_pad(Session::get('service'),48,".",STR_PAD_LEFT))); ?>

                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        MOTORISTA: <?php echo e(mb_strtoupper(str_pad(Session::get('driver'),45,".",STR_PAD_LEFT))); ?>

                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        VEÍCULO: <?php echo e(mb_strtoupper(str_pad(Session::get('car'),47,".",STR_PAD_LEFT))); ?>

                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        LOCALIDADE: <?php echo e(mb_strtoupper(str_pad(Session::get('place'),45,".",STR_PAD_LEFT))); ?>

                                    </font>
                                </p>
                            </div>
                            <br>
                            <div style="text-align: center" class="center">
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        <?php echo e(str_pad('',56,"-",STR_PAD_LEFT)); ?>

                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        APRESENTAR COMPROVANTE NA GARAGEM
                                    </font>
                                </p>
                                <p class="margin">
                                    <font size="2" face="Courier">
                                        <?php echo e(str_pad('',56,"-",STR_PAD_LEFT)); ?>

                                    </font>
                                </p>
                            </div>
                            <br>
                            <br>
                            <div style="text-align: center">
                                <p class="margin center">
                                    <font size="2" face="Courier">
                                        <?php echo e(str_pad('',56,"-",STR_PAD_LEFT)); ?>

                                    </font>
                                </p>
                                <p class="margin center">
                                    <font size="2" face="Courier">
                                        ASSINATURA DO RESPONSÁVEL
                                    </font>
                                </p>
                            </div>
                            <br>
                        </div>
                    </div>

                    <div class="row col s12 center mb-5" style="padding-left:30px; padding-right:30px">
                            <button  onclick="PrintDiv()" class="animated zoomInDown gradient-45deg-purple-deep-orange gradient-shadow waves-effect waves-light btn border-round left">Imprimir</button>
                            <a href="<?php echo e(route('services.car.out.receipt.print')); ?>" class="animated zoomInDown gradient-45deg-purple-deep-orange gradient-shadow waves-effect waves-light btn border-round">Baixar</a>
                            <a href="<?php echo e(route('login.out')); ?>" class="animated zoomInDown gradient-45deg-purple-deep-orange gradient-shadow waves-effect waves-light btn border-round right">Encerrar</a>
                    </div>
                
                    <?php $__env->startSection('js'); ?>
                        <script>
                            function PrintDiv(div)
                            {
                                $('#div-print').printElement(/*{printMode:'popup'}*/);
                            }
                            /*function print(){
                                var conteudo = document.getElementById('div-print').innerHTML,
                                tela_impressao = window.open('about:blank');
                                tela_impressao.document.write(conteudo);
                                tela_impressao.window.print();
                                tela_impressao.window.close();
                            }*/
                        </script>
                    <?php $__env->stopSection(); ?>
                    
                <?php break; ?>

                <?php case ('8'): ?>

                <style>
                
                .container {
                /*position: relative;
                width: 480px;
                height: 320px;*/
                overflow: auto;
                }

                .container .content {
                /*background-image: url('https://i.imgur.com/nAUUNzH.jpg');
                width: 1280px;
                height: 720px;*/
                }
                
                </style>

                <div class="card scrollspy border-radius-10 fixed-width z-depth-3 mb-10">
                    <div class="card-content p-0">
                        <br>
                        <br>
                        <ul class="container collection" style="max-height: 262px">
                            <li class="collection-item animate fadeUp delay-1 avatar">
                                <img src="./../../../../img/cars/spacefox.png" alt="" class="circle z-depth-2 responsive-img avatar mt-3" style=" z-index: 0">
                                <img src="./../../../../img/drivers/0437000698.jpg" alt="" class="circle z-depth-2 responsive-img avatar mt-3 ml-6" style=" z-index: 1">
                                <span class="title ml-9">Emissor: Cleiton Corrêa da Silva</span>
                                <p class="ml-9">Veiculo: Space <br>
                                    Motorista: Milton Paulo
                                </p>
                                <a href="#!" class="secondary-content mt-3"><i class="ion-flag red-text" style="font-size:30px"></i></a>
                            </li>
                            <li class="collection-item animate fadeUp delay-2 avatar">
                                <img src="./../../../../img/cars/fiorino.gif" alt="" class="circle z-depth-2 responsive-img avatar mt-3">
                                <img src="./../../../../img/drivers/0432800306.jpg" alt="" class="circle z-depth-2 responsive-img avatar mt-3 ml-6" style=" z-index: 1">
                                <span class="title ml-9">Emissor: Cleiton Corrêa da Silva</span>
                                <p class="ml-9">Veiculo: Fiorino <br>
                                    Motorista: Gilmar Mendes
                                </p>
                                <a href="#!" class="secondary-content mt-3"><i class="ion-flag red-text" style="font-size:30px"></i></a>
                            </li>
                            <li class="collection-item animate fadeUp delay-3 avatar">
                                <img src="./../../../../img/cars/doblo.jpg" alt="" class="circle z-depth-2 responsive-img avatar mt-3">
                                <img src="./../../../../img/drivers/0437000804.jpg" alt="" class="circle z-depth-2 responsive-img avatar mt-3 ml-6" style=" z-index: 1">
                                <span class="title ml-9">Emissor: Cleiton Corrêa da Silva</span>
                                <p class="ml-9">Veiculo: Dòblo <br>
                                    Motorista: João Paulo
                                </p>
                                <a href="#!" class="secondary-content mt-3"><i class="ion-flag red-text" style="font-size:30px"></i></a>
                            </li>
                            <li class="collection-item animate fadeUp delay-4 avatar">
                                <img src="./../../../../img/cars/doblo.jpg" alt="" class="circle z-depth-2 responsive-img avatar mt-3">
                                <img src="./../../../../img/drivers/0432800342.jpg" alt="" class="circle z-depth-2 responsive-img avatar mt-3 ml-6" style=" z-index: 1">
                                <span class="title ml-9">Emissor: Cleiton Corrêa da Silva</span>
                                <p class="ml-9">Veiculo: Dòblo  <br>
                                    Motorista: Paulo Vitor
                                </p>
                                <a href="#!" class="secondary-content mt-3"><i class="ion-flag red-text" style="font-size:30px"></i></a>
                            </li>
                        </ul>
                        <br>
                        <br>
                    </div>
                </div>
  
                <?php $__env->startSection('js'); ?>

                <script src="./../../../../vendor/perfect-scrollbar/dist/perfect-scrollbar.js"></script>

                <script>
                
                var ps = new PerfectScrollbar('.container');

                </script>
                
                <?php $__env->stopSection(); ?>

                <?php break; ?>

                <?php default: ?>

            <?php endswitch; ?>  
          
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>