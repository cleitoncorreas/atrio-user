<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-return-visibility','hidden'); ?>
<!--@section('button-return-color','')-->
<!--@section('button-return-href','')-->

<!------------------------------------------------------------------------------------------>

<!--@section('logo-avatar', './img/logo-menu/logo.png')-->
<?php $__env->startSection('title-grid', config('atrio.title')); ?>
<?php $__env->startSection('subtitle-grid', 'Controle de Portaria'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('button-option1-href','option-login'); ?>
<!--@section('button-option1.1-color','gradient-45deg-purple-deep-orange')-->
<?php $__env->startSection('button-option1-name','Iniciar'); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '1'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>