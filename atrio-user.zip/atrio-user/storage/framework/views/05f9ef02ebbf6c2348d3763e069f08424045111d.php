<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<?php $__env->startSection('button-return-visibility','hidden'); ?>

<?php $__env->startSection('logo-avatar', './../../../img/logo-menu/receipt.png'); ?>
<?php $__env->startSection('title-grid', 'Comprovante'); ?>
<?php $__env->startSection('title-color','purple'); ?>
<?php $__env->startSection('subtitle-grid', 'Apresente na garagem '); ?>


<?php echo $__env->make('vendor.templates.page',['option' => '7'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>