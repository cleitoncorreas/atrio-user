<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<!--@section('button-visibility','hidden')-->
<?php $__env->startSection('button-return-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('title-color','purple'); ?>

<?php if(Session::get('driverYn')=='yes'): ?>

    <?php $__env->startSection('button-return-href','/services/car/out'); ?>

<?php else: ?> 

    <?php $__env->startSection('button-return-href','/services/car/out/list/drivers'); ?>

<?php endif; ?>

<?php $__env->startSection('logo-avatar', './../../../../img/logo-menu/cars.png'); ?>
<?php $__env->startSection('title-grid', 'Veículos'); ?>
<?php $__env->startSection('subtitle-grid', 'Selecione o veículo desejado'); ?>

<!--@section('carousel-image','')-->
<?php $__env->startSection('card-content-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-prev-next-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('form-action','car/select'); ?>
<?php $__env->startSection('form-input-name','id_veiculo'); ?>
<?php $__env->startSection('button-select-color','gradient-45deg-purple-deep-orange'); ?>

<?php echo $__env->make('vendor.templates.page',['option' => '5'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>