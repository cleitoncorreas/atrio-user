<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<!--@section('button-visibility','hidden')-->
<?php $__env->startSection('button-return-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-return-href','/services/car/out/list/cars'); ?>

<?php $__env->startSection('logo-avatar', './../../../../img/logo-menu/places.png'); ?>
<?php $__env->startSection('title-grid', 'Localidades'); ?>
<?php $__env->startSection('title-color','purple'); ?>
<?php $__env->startSection('subtitle-grid', 'selecione a localidade desejada'); ?>

<!--@section('carousel-image','')-->
<?php $__env->startSection('card-content-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-prev-next-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('form-action','place/select'); ?>
<?php $__env->startSection('form-input-name','id_localidade'); ?>
<?php $__env->startSection('button-select-color','gradient-45deg-purple-deep-orange'); ?>


<?php echo $__env->make('vendor.templates.page',['option' => '5'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>