<?php $__env->startSection('title', 'PortControl | 1.0'); ?>

<?php $__env->startSection('button-return'); ?>

    <form action="<?php echo e(route('services.car.out.cars')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

        <div>
            <!--<input type="hidden" name="id_veiculo" class="id_veiculo" value="">-->
            <button  type="submit" class="btn-floating gradient-45deg-indigo-light-blue blue btn-large waves-effect waves-light pulse"><i class="material-icons">arrow_back</i></button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo-avatar', './../../../img/logo-menu/place.png'); ?>

<?php $__env->startSection('title-grid', 'Localidades'); ?>

<?php $__env->startSection('subtitle-grid', 'Selecione a localidade desejada'); ?>

<?php $__env->startSection('options'); ?>

<style>

    .bg-image-1 {
    background-image: url("./../../../img/cars/savero.jpg");
    width: 100%;
    height: 100%;
    background-size: cover;
    }
    
    .bg-image-2 {
    background-image: url("./../../../img/cars/spacefox.png");
    width: 100%;
    height: 100%;
    background-size: cover;
    }
    
    .bg-image-3 {
    background-image: url("./../../../img/cars/doblo.jpg");
    width: 100%;
    height: 100%;
    background-size: cover;
    }

    .bg-image-4 {
    background-image: url("./../../../img/cars/fiorino.gif");
    width: 100%;
    height: 100%;
    background-size: cover;
    }

    .bg-image-5 {
    background-image: url("./../../../img/places/cejpn.jpg");
    width: 100%;
    height: 100%;
    background-size: cover;
    }
    
    .bg-image-6 {
    background-image: url("./../../../img/places/niteroi.jpg");
    width: 100%;
    height: 100%;
    background-size: cover;
    }
    
    .bg-image-7 {
    background-image: url("./../../../img/places/petropolis2.jpg");
    width: 100%;
    height: 100%;
    background-size: cover;
    }

    .bg-image-8 {
    background-image: url("./../../../img/2.png");
    width: 100%;
    height: 100%;
    background-size: cover;
    }

</style>

<div class="center col s12">
    <div class="row carousel carousel-slider border-round" data-indicators="true">
        <div class="col s12 m4 carousel-item" data-cindex="0" id="seletor">
            <div class="card blue-grey darken-4 bg-image-5 z-depth-5 responsive-img border-round">
                <div class="input-field gradient-45deg-indigo-light-blue blue card-content card-panel col s6 z-depth-5" style="opacity:.8">
                    <span class="card-title font-weight-600 mb-10 white-text">CEJPN</span>
                    <p class="white-text">DelCastilho
                    <br> RJ</p>
                </div>
            </div>
        </div>
        <div class="col s12 m4 carousel-item"  data-cindex="1" id="seletor">
            <div class="card blue-grey darken-4 bg-image-6 z-depth-5 responsive-img border-round">
                <div class="input-field gradient-45deg-indigo-light-blue blue card-content card-panel col s6 z-depth-5" style="opacity:.8">
                    <span class="card-title font-weight-600 mb-10 white-text">CCAS</span>
                    <p class="white-text">Niterói
                    <br> RJ</p>
                </div>
            </div>
        </div>
        <div class="col s12 m4 carousel-item"  data-cindex="2" id="seletor">
            <div class="card blue-grey darken-4 bg-image-7 z-depth-5 responsive-img border-round">
                <div class="input-field gradient-45deg-indigo-light-blue blue card-content card-panel col s6 z-depth-5" style="opacity:.8">
                    <span class="card-title font-weight-600 mb-10 white-text">CCAS</span>
                    <p class="white-text">Petrópolis
                    <br> RJ</p>
                </div>
            </div>
        </div>
        <div class="col s12 m4 carousel-item"  data-cindex="2" id="seletor">
            <div class="card blue-grey darken-4 bg-image-8 z-depth-5 responsive-img border-round">
                <div class="input-field gradient-45deg-indigo-light-blue blue card-content card-panel col s6 z-depth-5" style="opacity:.8">
                    <span class="card-title font-weight-600 mb-10 white-text">Outros</span>
                    <p class="white-text">Solicitar ao administrador
                    <br> Administrador</p>
                </div>
            </div>
        </div>
    </div>
    <a class="btn-floating  gradient-45deg-indigo-light-blue blue waves-effect waves-light pulse left prev" style="bottom:100px; margin: 20px"><i class="material-icons">arrow_back</i></a>
    <a class="btn-floating  gradient-45deg-indigo-light-blue blue waves-effect waves-light pulse right next" style="bottom:100px; margin: 20px"><i class="material-icons">arrow_forward</i></a>
    
    <form action="<?php echo e(route('services.car.out.summary')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

        <div>
            <input type="hidden" name="id_localidade" class="id_localidade" value="">
            <button  type="submit" class="gradient-45deg-deep-orange-orange amber waves-effect waves-light btn border-round box-shadow pulse">Selecionar</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>

$(document).ready(function(){

// function change
    function changeIndex(index){
        $('.id_localidade').val(index);
    }

//active carousel
    $('.carousel.carousel-slider').carousel({
        onCycleTo: function(index){
            changeIndex($(index).data('cindex'));
        }
    });

// function for next slide
    $('.next').click(function(){
        $('.carousel').carousel('next');
    });

// function for prev slide
    $('.prev').click(function(){
        $('.carousel').carousel('prev');
    });

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.templates.page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>