<?php $__env->startSection('background','gradient-45deg-indigo-purple'); ?>

<!------------------------------------------------------------------------------------------>

<!--@section('button-visibility','hidden')-->
<?php $__env->startSection('button-return-color','gradient-45deg-purple-deep-orange'); ?>
<?php $__env->startSection('button-return-href','/services/car'); ?>

<!------------------------------------------------------------------------------------------>

<?php $__env->startSection('logo-avatar', './../../img/logo-menu/out.png'); ?>
<?php $__env->startSection('title-grid', 'Devolução'); ?>
<?php $__env->startSection('title-color','purple'); ?>
<?php $__env->startSection('subtitle-grid', 'encerre as saídas em abertas'); ?>
<?php echo $__env->make('vendor.templates.page',['option' => '8'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>