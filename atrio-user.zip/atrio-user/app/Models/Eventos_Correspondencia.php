<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Eventos_Correspondencia extends Model
{
    protected $connection = 'another';
}
