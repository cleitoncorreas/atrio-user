@extends('vendor.templates.page',['option' => '8'])
@section('background','gradient-45deg-indigo-purple')

<!------------------------------------------------------------------------------------------>

<!--@@section('button-visibility','hidden')-->
@section('button-return-color','gradient-45deg-purple-deep-orange')
@section('button-return-href','/services/car')

<!------------------------------------------------------------------------------------------>

@section('logo-avatar', './../../img/logo-menu/out.png')
@section('title-grid', 'Devolução')
@section('title-color','purple')
@section('subtitle-grid', 'encerre as saídas em abertas')